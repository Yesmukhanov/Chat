package com.example.chat;


public class Tostart {
    public static void main(String[] args) {
        ServerMain serverMain = new ServerMain();
        serverMain.start();
    }
}
